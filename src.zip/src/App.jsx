import './App.css'

function App() {

  return (
    <>
      <h1>dev life</h1>
    </>
  )
}

export default App
